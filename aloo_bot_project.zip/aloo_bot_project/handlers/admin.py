from __future__ import annotations

import io
from datetime import datetime

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import BufferedInputFile, CallbackQuery, Message
from openpyxl import Workbook

from config import settings
from database import db
from keyboards import admin_menu, build_calendar, main_menu, winner_keyboard
from random_system import RANDOM_STATE, RandomPicker, STATUS_MAP, run_random_draw
from utils import esc, format_dt

router = Router(name='admin')


class BroadcastState(StatesGroup):
    waiting_content = State()


class SearchState(StatesGroup):
    waiting_query = State()


@router.message(F.text == '🏠 Asosiy menyu')
async def to_main(message: Message):
    await message.answer('🏠 Asosiy menyuga qaytdingiz.', reply_markup=main_menu())


@router.message(F.text == '📊 Statistika')
async def stats(message: Message):
    if message.from_user.id not in settings.admin_ids:
        return
    s = await db.get_stats()
    await message.answer(
        f'📊 <b>Bot statistikasi</b>\n\n'
        f'👥 Umumiy foydalanuvchilar: <b>{s["total_users"]}</b>\n'
        f'✅ Ro‘yxatdan o‘tganlar: <b>{s["registered"]}</b>\n'
        f'🔗 Referallar: <b>{s["referrals"]}</b>\n'
        f'💎 Jami ballar: <b>{s["diamonds"]}</b>'
    )


@router.message(F.text == '🏆 Admin top ranking')
async def admin_top(message: Message):
    if message.from_user.id not in settings.admin_ids:
        return
    from handlers.ranking import top_ranking
    await top_ranking(message)


@router.message(F.text == '📣 Broadcast')
async def broadcast_start(message: Message, state: FSMContext):
    if message.from_user.id not in settings.admin_ids:
        return
    await state.set_state(BroadcastState.waiting_content)
    await message.answer('📣 Barcha foydalanuvchilarga yubormoqchi bo‘lgan xabaringizni yuboring.\n\nBekor qilish uchun /cancel deb yozing.')


@router.message(F.text == '🔎 User qidirish')
async def search_start(message: Message, state: FSMContext):
    if message.from_user.id not in settings.admin_ids:
        return
    await state.set_state(SearchState.waiting_query)
    await message.answer('🔎 User ID yoki username yuboring. Masalan: <code>1962467047</code> yoki <code>@username</code>')


@router.message(SearchState.waiting_query)
async def search_user(message: Message, state: FSMContext):
    if message.from_user.id not in settings.admin_ids:
        return
    user = await db.search_user((message.text or '').strip())
    await state.clear()
    if not user:
        await message.answer('❌ User topilmadi.', reply_markup=admin_menu())
        return
    await message.answer(
        f'👤 <b>User topildi</b>\n\n'
        f'ID: <code>{user["user_id"]}</code>\n'
        f'Ism: <b>{esc(user["first_name"])} {esc(user["last_name"] or "")}</b>\n'
        f'Username: <b>@{esc(user["username"] or "yo‘q")}</b>\n'
        f'Viloyat: <b>{esc(user["region"] or "yo‘q")}</b>\n'
        f'Ball: <b>{user["diamonds"]}</b>\n'
        f'Referal: <b>{user["referral_count"]}</b>\n'
        f'Ro‘yxatdan o‘tgan: <b>{format_dt(user["registered_at"])}</b>',
        reply_markup=admin_menu(),
    )


@router.message(F.text == '📦 G‘oliblar')
async def winners(message: Message):
    if message.from_user.id not in settings.admin_ids:
        return
    rows = await db.get_recent_winners(20)
    if not rows:
        await message.answer('Hozircha g‘oliblar yo‘q.')
        return
    lines = ['📦 <b>G‘oliblar ro‘yxati</b>\n']
    for row in rows:
        lines.append(
            f'ID #{row["id"]} — <b>{esc(row["winner_name"])}</b>\n'
            f'📅 {row["start_date"]} — {row["end_date"]}\n'
            f'📦 Status: {esc(row["winner_status"] or "—")}\n'
            f'🕒 {format_dt(row["created_at"])}'
        )
    await message.answer('\n\n'.join(lines))


@router.callback_query(F.data.startswith('winner_status:'))
async def update_winner_status(callback: CallbackQuery):
    if callback.from_user.id not in settings.admin_ids:
        await callback.answer('Ruxsat yo‘q', show_alert=True)
        return
    _, history_id, status_key = callback.data.split(':', 2)
    status = STATUS_MAP.get(status_key)
    if not status:
        await callback.answer('Noto‘g‘ri status', show_alert=True)
        return
    await db.update_winner_status(int(history_id), status)
    await callback.answer('Status yangilandi')
    await db.add_admin_log(callback.from_user.id, 'winner_status', f'{history_id} => {status}')


@router.message(F.text == '📥 Excel export')
async def excel_export(message: Message, bot):
    if message.from_user.id not in settings.admin_ids:
        return
    rows = await db.get_all_users()
    wb = Workbook()
    ws = wb.active
    ws.title = 'Users'
    ws.append(['User ID', 'Username', 'Ism', 'Familiya', 'Telefon', 'Viloyat', 'Tuman/Shahar', 'Ro‘yxatdan o‘tganmi', 'Ball', 'Takliflar', 'Referrer ID', 'Joined At', 'Registered At'])
    for row in rows:
        ws.append([
            row['user_id'], row['username'] or '', row['first_name'] or '', row['last_name'] or '', row['phone'] or '',
            row['region'] or '', row['district'] or '', 'ha' if row['is_registered'] else 'yo‘q', row['diamonds'], row['referral_count'], row['referrer_id'] or '',
            format_dt(row['joined_at']), format_dt(row['registered_at'])
        ])
    bio = io.BytesIO()
    wb.save(bio)
    bio.seek(0)
    await bot.send_document(message.chat.id, BufferedInputFile(bio.read(), filename='aloo_users.xlsx'), caption='📥 Foydalanuvchilar ro‘yxati')


@router.message(BroadcastState.waiting_content)
async def broadcast_send(message: Message, state: FSMContext, bot):
    if message.from_user.id not in settings.admin_ids:
        return
    users = await db.get_all_users()
    sent = 0
    failed = 0
    status = await message.answer('⏳ Broadcast yuborilmoqda...')
    for user in users:
        try:
            await bot.copy_message(chat_id=user['user_id'], from_chat_id=message.chat.id, message_id=message.message_id)
            sent += 1
        except Exception:
            failed += 1
    await state.clear()
    await db.add_admin_log(message.from_user.id, 'broadcast', f'sent={sent};failed={failed}')
    await status.edit_text(f'✅ Broadcast tugadi.\n\n📤 Yuborildi: <b>{sent}</b>\n❌ Xato: <b>{failed}</b>')
    await message.answer('🛠 Admin panel', reply_markup=admin_menu())


@router.message(F.text == '🎲 Random o‘yin')
async def random_start(message: Message):
    if message.from_user.id not in settings.admin_ids:
        return
    state = RandomPicker(year=datetime.now().year, month=datetime.now().month)
    RANDOM_STATE[message.from_user.id] = state
    await message.answer('📅 <b>Random o‘yin</b>\n\nAvval <b>boshlanish sana</b>ni tanlang:', reply_markup=build_calendar(state))


@router.callback_query(F.data == 'cal_ignore')
async def cal_ignore(callback: CallbackQuery):
    await callback.answer()


@router.callback_query(F.data == 'cal_prev')
async def cal_prev(callback: CallbackQuery):
    state = RANDOM_STATE.get(callback.from_user.id, RandomPicker(year=datetime.now().year, month=datetime.now().month))
    if state.month == 1:
        state.month = 12
        state.year -= 1
    else:
        state.month -= 1
    RANDOM_STATE[callback.from_user.id] = state
    await callback.message.edit_reply_markup(reply_markup=build_calendar(state))
    await callback.answer()


@router.callback_query(F.data == 'cal_next')
async def cal_next(callback: CallbackQuery):
    state = RANDOM_STATE.get(callback.from_user.id, RandomPicker(year=datetime.now().year, month=datetime.now().month))
    if state.month == 12:
        state.month = 1
        state.year += 1
    else:
        state.month += 1
    RANDOM_STATE[callback.from_user.id] = state
    await callback.message.edit_reply_markup(reply_markup=build_calendar(state))
    await callback.answer()


@router.callback_query(F.data.startswith('cal_pick:'))
async def cal_pick(callback: CallbackQuery):
    if callback.from_user.id not in settings.admin_ids:
        await callback.answer('Ruxsat yo‘q', show_alert=True)
        return
    picked = callback.data.split(':', 1)[1]
    state = RANDOM_STATE.get(callback.from_user.id)
    if not state:
        state = RandomPicker(year=datetime.now().year, month=datetime.now().month)
    if not state.start_date:
        state.start_date = picked
        RANDOM_STATE[callback.from_user.id] = state
        await callback.message.edit_text(f'✅ Boshlanish sana: <b>{state.start_date}</b>\n\nEndi <b>tugash sana</b>ni tanlang:', reply_markup=build_calendar(state))
        await callback.answer('Boshlanish sana tanlandi')
        return
    if not state.end_date:
        if picked < state.start_date:
            await callback.answer('Tugash sana boshlanish sanadan oldin bo‘lishi mumkin emas.', show_alert=True)
            return
        state.end_date = picked
        RANDOM_STATE[callback.from_user.id] = state
        await callback.message.edit_text(
            f'✅ Boshlanish sana: <b>{state.start_date}</b>\n✅ Tugash sana: <b>{state.end_date}</b>\n\n🎯 Endi g‘olibni aniqlash tugmasini bosing.',
            reply_markup=build_calendar(state),
        )
        await callback.answer('Tugash sana tanlandi')
        return
    state.start_date = picked
    state.end_date = None
    RANDOM_STATE[callback.from_user.id] = state
    await callback.message.edit_text(f'✅ Yangi boshlanish sana: <b>{state.start_date}</b>\n\nEndi tugash sanasini tanlang:', reply_markup=build_calendar(state))
    await callback.answer('Boshlanish sana yangilandi')


@router.callback_query(F.data == 'random_cancel')
async def random_cancel(callback: CallbackQuery):
    RANDOM_STATE.pop(callback.from_user.id, None)
    await callback.message.edit_text('❌ Random o‘yin bekor qilindi.')
    await callback.answer()


@router.callback_query(F.data == 'random_draw')
async def random_draw(callback: CallbackQuery, bot):
    if callback.from_user.id not in settings.admin_ids:
        await callback.answer('Ruxsat yo‘q', show_alert=True)
        return
    await run_random_draw(callback, bot)
