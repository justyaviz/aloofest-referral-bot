from __future__ import annotations

from aiohttp import web

from config import settings
from web.api import health, register_api, register_page


async def setup_web_server() -> web.AppRunner:
    app = web.Application()
    app.router.add_get('/health', health)
    app.router.add_get('/register', register_page)
    app.router.add_post('/api/register', register_api)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, '0.0.0.0', settings.port)
    await site.start()
    return runner
