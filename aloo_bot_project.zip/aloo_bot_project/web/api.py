from __future__ import annotations

from aiohttp import web

from database import db
from handlers.contest import DISTRICTS
from utils import verify_uid
from web.register_page import build_registration_page


async def health(request: web.Request) -> web.Response:
    return web.Response(text='OK')


async def register_page(request: web.Request) -> web.Response:
    try:
        uid = int(request.query.get('uid', '0'))
    except ValueError:
        return web.Response(text='Noto‘g‘ri uid', status=400)

    sig = request.query.get('sig', '')
    if not uid or not verify_uid(uid, sig):
        return web.Response(text='Ruxsat yo‘q', status=403)

    user = await db.get_user(uid)
    if not user:
        return web.Response(text='Foydalanuvchi topilmadi. Avval botda /start bosing va qayta urinib ko‘ring.', status=404)

    html_page = build_registration_page(
        uid=uid,
        signature=sig,
        first_name=user['first_name'] or '',
        last_name=user['last_name'] or '',
        region=user['region'] or '',
        district=user['district'] or '',
        districts=DISTRICTS,
    )
    return web.Response(text=html_page, content_type='text/html')


async def register_api(request: web.Request) -> web.Response:
    try:
        data = await request.json()
    except Exception:
        return web.json_response({'ok': False, 'error': 'Noto‘g‘ri so‘rov'})

    uid = int(data.get('uid', 0))
    sig = data.get('sig', '')
    first_name = str(data.get('first_name', '')).strip()
    last_name = str(data.get('last_name', '')).strip()
    region = str(data.get('region', '')).strip()
    district = str(data.get('district', '')).strip()

    if not uid or not verify_uid(uid, sig):
        return web.json_response({'ok': False, 'error': 'Ruxsat yo‘q'})
    if not first_name:
        return web.json_response({'ok': False, 'error': 'Ism kiritilishi shart'})
    if not last_name:
        return web.json_response({'ok': False, 'error': 'Familiya kiritilishi shart'})
    if region not in DISTRICTS:
        return web.json_response({'ok': False, 'error': 'Viloyat noto‘g‘ri'})
    if district not in DISTRICTS[region]:
        return web.json_response({'ok': False, 'error': 'Tuman/Shahar noto‘g‘ri'})

    user = await db.get_user(uid)
    if not user:
        return web.json_response({'ok': False, 'error': 'Foydalanuvchi topilmadi. Avval botda /start bosing.'})

    ok, msg = await db.register_user(uid, user['username'], first_name, last_name, region, district)
    if not ok:
        return web.json_response({'ok': False, 'error': msg})
    return web.json_response({'ok': True})
