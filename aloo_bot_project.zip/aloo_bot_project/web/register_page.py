from __future__ import annotations

import html
import json


def build_registration_page(uid: int, signature: str, first_name: str, last_name: str, region: str, district: str, districts: dict[str, list[str]]) -> str:
    region_options = ''.join(
        f'<option value="{html.escape(r)}" {"selected" if r == region else ""}>{html.escape(r)}</option>'
        for r in districts.keys()
    )
    districts_json = json.dumps(districts, ensure_ascii=False)

    return f'''<!DOCTYPE html>
<html lang="uz">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <title>aloo ro‘yxatdan o‘tish</title>
  <style>
    * {{ box-sizing: border-box; }}
    body {{ margin: 0; font-family: Arial, sans-serif; background: linear-gradient(135deg, #071222, #0f1d39); color: #fff; }}
    .wrap {{ max-width: 500px; margin: 0 auto; padding: 18px; }}
    .card {{ margin-top: 18px; padding: 22px; border-radius: 20px; background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.12); box-shadow: 0 18px 45px rgba(0,0,0,.28); }}
    h1 {{ margin: 0 0 8px; font-size: 25px; }}
    p {{ color: #dbe7ff; line-height: 1.5; }}
    label {{ display:block; margin-top: 14px; margin-bottom: 6px; color: #d8e6ff; font-size: 14px; }}
    input, select {{ width: 100%; border-radius: 12px; border: 1px solid rgba(255,255,255,.15); padding: 14px; background: rgba(255,255,255,.08); color: #fff; font-size: 15px; outline: none; }}
    option {{ color: #111; }}
    button {{ width: 100%; margin-top: 18px; border: 0; border-radius: 12px; padding: 15px; cursor: pointer; font-size: 16px; font-weight: 700; color: #fff; background: linear-gradient(90deg, #22c55e, #16a34a); }}
    .ok, .err {{ display:none; margin-top: 14px; padding: 12px; border-radius: 12px; font-size: 14px; }}
    .ok {{ background: rgba(34,197,94,.15); border: 1px solid rgba(34,197,94,.4); color: #dcfce7; }}
    .err {{ background: rgba(239,68,68,.15); border: 1px solid rgba(239,68,68,.4); color: #fee2e2; }}
    .note {{ margin-top: 10px; font-size: 13px; color: #cbd5e1; }}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>🎉 aloo konkurs ro‘yxati</h1>
      <p>Formani to‘ldiring va <b>aloofest</b> konkursida ishtirokingizni faollashtiring.</p>
      <form id="form">
        <label>Ism</label>
        <input id="first_name" value="{html.escape(first_name)}" required />

        <label>Familiya</label>
        <input id="last_name" value="{html.escape(last_name)}" required />

        <label>Viloyatingizni tanlang</label>
        <select id="region" required>
          <option value="">Tanlang</option>
          {region_options}
        </select>

        <label>Shahar yoki tumaningizni tanlang</label>
        <select id="district" required>
          <option value="">Avval viloyat tanlang</option>
        </select>

        <button type="submit">RO‘YXATDAN O‘TISH</button>
        <div class="note">Ma’lumotlaringiz saqlanadi va keyingi kirishda yo‘qolmaydi.</div>
        <div class="ok" id="ok"></div>
        <div class="err" id="err"></div>
      </form>
    </div>
  </div>

<script>
const uid = {uid};
const sig = {json.dumps(signature)};
const districts = {districts_json};
const selectedRegion = {json.dumps(region, ensure_ascii=False)};
const selectedDistrict = {json.dumps(district, ensure_ascii=False)};

const regionEl = document.getElementById('region');
const districtEl = document.getElementById('district');
const form = document.getElementById('form');
const okBox = document.getElementById('ok');
const errBox = document.getElementById('err');

function loadDistricts(region, selected='') {{
  districtEl.innerHTML = '';
  if (!region || !districts[region]) {{
    districtEl.innerHTML = '<option value="">Avval viloyat tanlang</option>';
    return;
  }}
  const first = document.createElement('option');
  first.value = '';
  first.textContent = 'Tanlang';
  districtEl.appendChild(first);

  districts[region].forEach(item => {{
    const opt = document.createElement('option');
    opt.value = item;
    opt.textContent = item;
    if (item === selected) opt.selected = true;
    districtEl.appendChild(opt);
  }});
}}

regionEl.addEventListener('change', () => loadDistricts(regionEl.value, ''));
if (selectedRegion) {{
  regionEl.value = selectedRegion;
  loadDistricts(selectedRegion, selectedDistrict);
}}

form.addEventListener('submit', async (e) => {{
  e.preventDefault();
  okBox.style.display = 'none';
  errBox.style.display = 'none';

  const payload = {{
    uid,
    sig,
    first_name: document.getElementById('first_name').value.trim(),
    last_name: document.getElementById('last_name').value.trim(),
    region: regionEl.value,
    district: districtEl.value,
  }};

  try {{
    const res = await fetch('/api/register', {{
      method: 'POST',
      headers: {{ 'Content-Type': 'application/json' }},
      body: JSON.stringify(payload),
    }});
    const data = await res.json();
    if (data.ok) {{
      okBox.textContent = '✅ Tabriklaymiz! Ma’lumotlaringiz saqlandi. Endi botga qaytib davom etishingiz mumkin.';
      okBox.style.display = 'block';
    }} else {{
      errBox.textContent = data.error || 'Xatolik yuz berdi';
      errBox.style.display = 'block';
    }}
  }} catch (err) {{
    errBox.textContent = 'Server bilan bog‘lanishda xatolik yuz berdi.';
    errBox.style.display = 'block';
  }}
}});
</script>
</body>
</html>'''
