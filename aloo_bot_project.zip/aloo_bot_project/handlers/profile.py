from __future__ import annotations

from aiogram import F, Router
from aiogram.types import Message

from database import db
from keyboards import profile_actions_keyboard
from utils import esc

router = Router(name='profile')


@router.message(F.text == '💎 Mening ballarim')
async def my_points(message: Message):
    user = await db.get_user(message.from_user.id)
    if not user or user['is_registered'] != 1:
        await message.answer('Avval ro‘yxatdan o‘ting.')
        return
    await message.answer(
        f'💎 <b>Mening ballarim</b>\n\n'
        f'💠 Jami ball: <b>{user["diamonds"]}</b>\n'
        f'👥 Taklif qilgan do‘stlar: <b>{user["referral_count"]}</b>\n\n'
        'Har bir muvaffaqiyatli do‘st uchun: <b>+5 💎</b>'
    )


@router.message(F.text == 'ℹ️ Mening profilim')
async def profile(message: Message):
    user = await db.get_user(message.from_user.id)
    if not user or user['is_registered'] != 1:
        await message.answer('Siz hali ro‘yxatdan o‘tmagansiz.')
        return

    await message.answer(
        f'👤 <b>Mening profilim</b>\n\n'
        f'Ism: <b>{esc(user["first_name"])}</b>\n'
        f'Familiya: <b>{esc(user["last_name"])}</b>\n'
        f'Viloyat: <b>{esc(user["region"])}</b>\n'
        f'Tuman/Shahar: <b>{esc(user["district"])}</b>\n'
        f'💎 Ball: <b>{user["diamonds"]}</b>\n'
        f'👥 Takliflar: <b>{user["referral_count"]}</b>',
        reply_markup=profile_actions_keyboard(message.from_user.id),
    )


@router.message(F.text == '📊 Mening o‘rnim')
async def my_rank(message: Message):
    user = await db.get_user(message.from_user.id)
    if not user or user['is_registered'] != 1:
        await message.answer('Avval ro‘yxatdan o‘ting.')
        return

    rank = await db.get_rank_for_user(message.from_user.id)
    total_rows = await db.get_top_users(999999)
    total = len(total_rows)
    prev_row, next_row = await db.get_neighbors(message.from_user.id)

    text = [
        '🏆 <b>Sizning o‘rningiz</b>\n',
        f'💎 Ball: <b>{user["diamonds"]}</b>',
        f'🏅 O‘rin: <b>{rank} / {total}</b>',
        '',
    ]
    if prev_row:
        text.append(f'Oldingizdagi user: <b>{esc(prev_row["first_name"])} {esc(prev_row["last_name"] or "")}</b> — {prev_row["diamonds"]} 💎')
    if next_row:
        text.append(f'Keyingizdagi user: <b>{esc(next_row["first_name"])} {esc(next_row["last_name"] or "")}</b> — {next_row["diamonds"]} 💎')
    await message.answer('\n'.join(text))


@router.message(F.text == '💎 Ball tarixi')
async def ball_history(message: Message):
    user = await db.get_user(message.from_user.id)
    if not user or user['is_registered'] != 1:
        await message.answer('Avval ro‘yxatdan o‘ting.')
        return

    rows = await db.get_ball_history(message.from_user.id)
    if not rows:
        await message.answer('💎 Hozircha ball tarixi yo‘q.')
        return

    lines = ['💎 <b>Ball tarixi</b>\n']
    for row in rows:
        sign = '+' if row['amount'] >= 0 else ''
        lines.append(f'{sign}{row["amount"]} 💎 — {esc(row["reason"])}')
    await message.answer('\n'.join(lines))
