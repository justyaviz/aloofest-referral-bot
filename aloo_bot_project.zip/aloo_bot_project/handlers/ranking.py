from __future__ import annotations

from aiogram import F, Router
from aiogram.types import Message

from database import db
from utils import esc, format_dt

router = Router(name='ranking')


@router.message(F.text == '🏆 Top ranking')
async def top_ranking(message: Message):
    rows = await db.get_top_users(10)
    if not rows:
        await message.answer('Hozircha reyting shakllanmagan.')
        return
    medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟']
    lines = ['🏆 <b>Top ranking — 💎 ball bo‘yicha</b>\n']
    for i, row in enumerate(rows, start=1):
        full_name = f"{row['first_name'] or ''} {row['last_name'] or ''}".strip()
        lines.append(f'{medals[i-1]} <b>{esc(full_name)}</b> — <b>{row["diamonds"]} 💎</b> | {row["referral_count"]} ta')
    await message.answer('\n'.join(lines))


@router.message(F.text == '🎁 Sovg‘alar')
async def prizes(message: Message):
    rows = await db.get_prizes()
    if not rows:
        await message.answer('Hozircha sovg‘alar kiritilmagan.')
        return
    lines = ['🎁 <b>aloofest sovg‘alari</b>\n']
    for row in rows:
        line = f"{esc(row['place_label'])} — <b>{esc(row['title'])}</b>"
        if row['description']:
            line += f"\n{esc(row['description'])}"
        lines.append(line)
    await message.answer('\n\n'.join(lines))


@router.message(F.text == '🕘 Random tarixi')
async def random_history(message: Message):
    rows = await db.get_random_history(15)
    if not rows:
        await message.answer('Hozircha random tarixi yo‘q.')
        return
    lines = ['🕘 <b>Random g‘oliblar tarixi</b>\n']
    for i, row in enumerate(rows, start=1):
        lines.append(
            f"{i}. <b>{esc(row['winner_name'])}</b>\n"
            f"📅 {row['start_date']} — {row['end_date']}\n"
            f"👥 Ishtirokchilar: {row['participants_count']}\n"
            f"📦 Status: {esc(row['winner_status'] or '—')}\n"
            f"🕒 {format_dt(row['created_at'])}"
        )
    await message.answer('\n\n'.join(lines))
