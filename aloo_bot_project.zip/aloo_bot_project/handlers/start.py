from __future__ import annotations

from aiogram.filters import Command, CommandStart
from aiogram.types import Message
from aiogram import Router

from database import db
from keyboards import admin_menu, main_menu
from config import settings

router = Router(name='start')


@router.message(CommandStart())
async def start_handler(message: Message):
    await db.create_or_touch_user(message.from_user.id, message.from_user.username, message.from_user.first_name)
    parts = (message.text or '').split(maxsplit=1)
    if len(parts) > 1 and parts[1].startswith('ref_'):
        raw = parts[1].replace('ref_', '').strip()
        if raw.isdigit():
            await db.set_referrer_if_empty(message.from_user.id, int(raw))

    await message.answer(
        '🎉 <b>aloo konkurs botiga xush kelibsiz!</b>\n\n'
        'Bu bot orqali siz konkursda qatnashishingiz, do‘stlaringizni taklif qilib 💎 ball yig‘ishingiz, top rankingga kirishingiz va random g‘oliblar tarixini ko‘rishingiz mumkin.\n\n'
        'Quyidagi menyudan kerakli bo‘limni tanlang.',
        reply_markup=main_menu(),
    )


@router.message(Command('admin'))
async def admin_panel(message: Message):
    if message.from_user.id not in settings.admin_ids:
        await message.answer('⛔ Sizda bu bo‘limga kirish huquqi yo‘q.')
        return
    await message.answer('🛠 <b>Admin panel</b>', reply_markup=admin_menu())
