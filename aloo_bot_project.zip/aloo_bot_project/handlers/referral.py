from __future__ import annotations

import os
from pathlib import Path

from aiogram import F, Router
from aiogram.types import BufferedInputFile, CallbackQuery, Message

from database import db
from referral_card import generate_referral_card

router = Router(name='referral')


async def _invite_url(bot, user_id: int) -> str:
    me = await bot.get_me()
    return f'https://t.me/{me.username}?start=ref_{user_id}'


@router.message(F.text == '🔗 Do‘st taklif qilish')
async def invite_friends(message: Message, bot):
    user = await db.get_user(message.from_user.id)
    if not user or user['is_registered'] != 1:
        await message.answer('Avval ro‘yxatdan o‘ting.')
        return
    link = await _invite_url(bot, message.from_user.id)
    await message.answer(
        f'🚀 <b>Do‘st taklif qilish havolangiz:</b>\n\n{link}\n\n'
        'Do‘stingiz ushbu havola orqali kirib ro‘yxatdan o‘tsa sizga <b>+5 💎</b> beriladi.'
    )


@router.callback_query(F.data == 'my_invite')
async def my_invite(callback: CallbackQuery, bot):
    link = await _invite_url(bot, callback.from_user.id)
    await callback.message.answer(
        f'🔗 <b>Sizning maxsus taklif havolangiz:</b>\n\n{link}\n\n'
        'Har bir muvaffaqiyatli ro‘yxatdan o‘tgan do‘st uchun sizga <b>+5 💎</b> yoziladi.'
    )
    await callback.answer()


@router.message(F.text == '🪪 Referral card')
async def referral_card(message: Message, bot):
    user = await db.get_user(message.from_user.id)
    if not user or user['is_registered'] != 1:
        await message.answer('Avval ro‘yxatdan o‘ting.')
        return
    full_name = f"{user['first_name'] or ''} {user['last_name'] or ''}".strip() or 'Noma’lum'
    link = await _invite_url(bot, message.from_user.id)
    temp_path = f'/tmp/ref_card_{message.from_user.id}.png'
    generate_referral_card(full_name, int(user['diamonds'] or 0), link, temp_path)
    with open(temp_path, 'rb') as f:
        data = f.read()
    await message.answer_photo(
        BufferedInputFile(data, filename='referral_card.png'),
        caption='🪪 <b>Sizning referral cardingiz</b>\n\nUni ulashing va do‘stlaringizni taklif qiling.',
    )
    try:
        os.remove(temp_path)
    except OSError:
        pass
