from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message

from database import db
from keyboards import profile_actions_keyboard, register_keyboard, subscribe_keyboard
from utils import is_channel_member

router = Router(name='contest')

DISTRICTS = {
    "Toshkent sh.": ["Bektemir", "Chilonzor", "Yakkasaroy", "Mirobod", "Mirzo Ulug‘bek", "Olmazor", "Sergeli", "Shayxontohur", "Uchtepa", "Yashnobod", "Yunusobod"],
    "Toshkent vil.": ["Angren", "Bekobod sh.", "Chirchiq", "Olmaliq", "Ohangaron sh.", "Yangiyo‘l sh.", "Nurafshon", "Bekobod tumani", "Bo‘ka", "Bo‘stonliq", "Chinoz", "Qibray", "Ohangaron tumani", "Oqqo‘rg‘on", "Parkent", "Piskent", "Quyi Chirchiq", "Yangiyo‘l tumani", "Yuqori Chirchiq", "Zangiota"],
    "Andijon": ["Andijon sh.", "Xonobod", "Andijon tumani", "Asaka", "Baliqchi", "Bo‘ston", "Buloqboshi", "Izboskan", "Jalaquduq", "Marhamat", "Oltinko‘l", "Paxtaobod", "Qo‘rg‘ontepa", "Shahrixon", "Ulug‘nor", "Xo‘jaobod"],
    "Farg‘ona": ["Farg‘ona sh.", "Qo‘qon", "Marg‘ilon", "Quvasoy", "Farg‘ona tumani", "Oltiariq", "Bag‘dod", "Beshariq", "Buvayda", "Dang‘ara", "Furqat", "Qo‘shtepa", "Quva", "Rishton", "So‘x", "Toshloq", "Uchko‘prik", "Yozyovon"],
    "Namangan": ["Namangan sh.", "Chust", "Kosonsoy", "Pop", "To‘raqo‘rg‘on", "Uychi", "Uchqo‘rg‘on", "Chortoq", "Mingbuloq", "Namangan tumani", "Norin", "Yangiqo‘rg‘on"],
    "Samarqand": ["Samarqand sh.", "Kattaqo‘rg‘on sh.", "Bulung‘ur", "Ishtixon", "Jomboy", "Kattaqo‘rg‘on tumani", "Qo‘shrabot", "Narpay", "Nurobod", "Oqdaryo", "Paxtachi", "Pastdarg‘om", "Payariq", "Samarqand tumani", "Toyloq", "Urgut"],
    "Buxoro": ["Buxoro sh.", "Kogon sh.", "Buxoro tumani", "G‘ijduvon", "Jondor", "Kogon tumani", "Olot", "Peshku", "Qorako‘l", "Qorovulbozor", "Romitan", "Shofirkon", "Vobkent"],
    "Xorazm": ["Urganch sh.", "Xiva sh.", "Bog‘ot", "Gurlan", "Xiva tumani", "Hazorasp", "Xonqa", "Qo‘shko‘pir", "Shovot", "Urganch tumani", "Yangiariq", "Yangibozor", "Tuproqqal’a"],
    "Qashqadaryo": ["Qarshi sh.", "Shahrisabz sh.", "Dehqonobod", "Kasbi", "Kitob", "Koson", "Ko‘kdala", "Mirishkor", "Muborak", "Nishon", "Qamashi", "Qarshi tumani", "Yakkabog‘", "Chiroqchi", "Shahrisabz tumani", "G‘uzor"],
    "Surxondaryo": ["Termiz sh.", "Angor", "Bandixon", "Boysun", "Denov", "Jarqo‘rg‘on", "Muzrabot", "Oltinsoy", "Qiziriq", "Qumqo‘rg‘on", "Sariosiyo", "Sherobod", "Sho‘rchi", "Termiz tumani", "Uzun"],
    "Navoiy": ["Navoiy sh.", "Zarafshon", "G‘ozg‘on", "Karmana", "Konimex", "Navbahor", "Nurota", "Qiziltepa", "Tomdi", "Uchquduq", "Xatirchi"],
    "Jizzax": ["Jizzax sh.", "Arnasoy", "Baxmal", "Do‘stlik", "Forish", "G‘allaorol", "Mirzacho‘l", "Paxtakor", "Yangiobod", "Zafarobod", "Zarbdor", "Zomin", "Sharof Rashidov"],
    "Sirdaryo": ["Guliston sh.", "Shirin", "Yangiyer", "Boyovut", "Guliston tumani", "Mirzaobod", "Oqoltin", "Sardoba", "Sayxunobod", "Sirdaryo", "Xovos"],
    "Qoraqalpog‘iston": ["Nukus sh.", "Amudaryo", "Beruniy", "Bo‘zatov", "Chimboy", "Ellikqal’a", "Kegeyli", "Mo‘ynoq", "Nukus tumani", "Qanliko‘l", "Qo‘ng‘irot", "Qorao‘zak", "Shumanay", "Taxtako‘pir", "To‘rtko‘l", "Xo‘jayli"],
}


@router.message(F.text == '🎉 Konkursda qatnashish')
async def contest_entry(message: Message):
    await db.create_or_touch_user(message.from_user.id, message.from_user.username, message.from_user.first_name)
    user = await db.get_user(message.from_user.id)
    if user and user['is_registered'] == 1:
        await message.answer(
            '✅ <b>Siz allaqachon ro‘yxatdan o‘tgansiz.</b>\n\nEndi do‘stlaringizni taklif qilib 💎 ball yig‘ishingiz mumkin.',
            reply_markup=profile_actions_keyboard(message.from_user.id),
        )
        return

    await message.answer(
        '📌 <b>Botdan foydalanish uchun quyidagilarni bajaring:</b>\n\n'
        '1️⃣ <b>Kanalga a’zo bo‘ling</b>\n'
        '2️⃣ <b>Onlayn do‘kon botida /start bosing</b>\n\n'
        'Hammasini bajarganingizdan so‘ng <b>✅ Tekshirish</b> tugmasini bosing.',
        reply_markup=subscribe_keyboard(),
    )


@router.callback_query(F.data == 'check_sub')
async def check_subscription(callback: CallbackQuery):
    user = await db.get_user(callback.from_user.id)
    if user and user['is_registered'] == 1:
        await callback.message.answer(
            '✅ <b>Siz ro‘yxatdan o‘tib bo‘lgansiz.</b>',
            reply_markup=profile_actions_keyboard(callback.from_user.id),
        )
        await callback.answer()
        return

    member = await is_channel_member(callback.from_user.id)
    if not member:
        await callback.message.answer(
            '❌ Siz hali kanalga a’zo bo‘lmagansiz.\n\nAvval obuna bo‘lib, keyin yana <b>✅ Tekshirish</b> tugmasini bosing.',
            reply_markup=subscribe_keyboard(),
        )
        await callback.answer('Obuna topilmadi', show_alert=True)
        return

    await callback.message.answer(
        '✅ <b>Zo‘r, obuna tasdiqlandi!</b>\n\nEndi konkurs ishtirokchisi bo‘lish uchun ro‘yxatdan o‘ting.',
        reply_markup=register_keyboard(callback.from_user.id),
    )
    await callback.answer('Obuna tasdiqlandi')
