from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message

from config import settings
from database import db
from keyboards import main_menu, support_menu
from utils import esc

router = Router(name='support')


class SupportState(StatesGroup):
    waiting_message = State()


@router.message(F.text == '📞 Bog‘lanish')
async def support_start(message: Message, state: FSMContext):
    await state.set_state(SupportState.waiting_message)
    await message.answer(
        '📞 <b>Bog‘lanish</b>\n\nIltimos, savolingiz yoki xabaringizni yuboring. Xabaringiz adminlarga jo‘natiladi.\n\nChiqish uchun <b>❌ Yakunlash</b> tugmasini bosing.',
        reply_markup=support_menu(),
    )


@router.message(F.text == '❌ Yakunlash')
async def support_stop(message: Message, state: FSMContext):
    if await state.get_state() == SupportState.waiting_message:
        await state.clear()
        await message.answer('✅ Bog‘lanish bo‘limidan chiqdingiz.', reply_markup=main_menu())


@router.message(SupportState.waiting_message)
async def support_message(message: Message, state: FSMContext, bot):
    user = await db.get_user(message.from_user.id)
    full_name = 'Noma’lum'
    if user and user['first_name']:
        full_name = f"{user['first_name']} {user['last_name'] or ''}".strip()
    user_text = message.text or message.caption or '[Media xabar]'
    payload = (
        f'📩 <b>Yangi bog‘lanish xabari</b>\n\n'
        f'👤 User ID: <code>{message.from_user.id}</code>\n'
        f'🧑 Ism: <b>{esc(full_name)}</b>\n'
        f'💬 Xabar:\n{esc(user_text)}'
    )
    sent = 0
    for admin_id in settings.admin_ids:
        try:
            msg = await bot.send_message(admin_id, payload)
            await db.save_support_map(admin_id, msg.message_id, message.from_user.id, user_text)
            sent += 1
        except Exception:
            pass
    await message.answer(f'✅ Xabaringiz yuborildi. ({sent} ta admin)')


@router.message(F.reply_to_message)
async def admin_reply(message: Message, bot):
    if message.from_user.id not in settings.admin_ids:
        return
    reply = message.reply_to_message
    if not reply:
        return
    mapping = await db.get_support_map(message.from_user.id, reply.message_id)
    if not mapping:
        return
    answer = message.text or message.caption or '[Javob]'
    original = mapping['user_text'] or '—'
    out = (
        '📞 <b>Admin javobi</b>\n\n'
        f'📝 <b>Sizning savolingiz:</b>\n{esc(original)}\n\n'
        f'💬 <b>Admin javobi:</b>\n{esc(answer)}'
    )
    try:
        await bot.send_message(mapping['user_id'], out)
        await message.reply('✅ Javob foydalanuvchiga yuborildi.')
    except Exception as exc:
        await message.reply(f'❌ Xatolik: {exc}')
